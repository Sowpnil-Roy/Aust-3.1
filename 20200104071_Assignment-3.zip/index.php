<html>
	<head>
	</head>
	<style>
div{
  background-color: #aac5f0;
  width: 300px;
  border: 5px solid gray;

}
</style>

  <body>
	
  <form action = "result.php" method="POST">

	<div>
	   <center>
		
	     <h4><p>Name</p></h4>
	        <p><input type="text" name="person_name" value="" placeholder="Enter your name"/></p>
	     <h4><p>Email</p></h4>
	        <p><input type="text" name="person_email" value="" placeholder="Enter your email address"/></p>
    	 <h4><p>Password</p></h4>
	        <p><input type="password" name="person_password" value="" placeholder="Enter your password"/></p>
        <input type="submit" name="" value="Submit"/>
    
      </center>
	
	</div>
   </form>
 </body>
</html>


