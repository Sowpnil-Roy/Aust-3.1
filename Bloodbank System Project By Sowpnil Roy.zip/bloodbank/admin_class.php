<?php

session_start();    // Start a session
ini_set('display_errors', 1);    // Set display errors
Class Action {    // Define a class Action
	private $db;    // Define a private variable db

	public function __construct() {    // Define a constructor
		ob_start();    // Start the output buffering
   	include 'db_connect.php';    // Include the db_connect.php file
    
    $this->db = $conn;    // Set value of private variable db
	}
	function __destruct() {    // Define a destructor
	    $this->db->close();    // Close the connection
	    ob_end_flush();    // Flush the output buffer
	}

	function login(){
		
		extract($_POST);		
		$qry = $this->db->query("SELECT * FROM users where username = '".$username."' and password = '".md5($password)."' ");
		if($qry->num_rows > 0){    // check if query returns any result or not
			foreach ($qry->fetch_array() as $key => $value) {    // Iterate through the results
				if($key != 'passwors' && !is_numeric($key))    // Perform check on the key
					$_SESSION['login_'.$key] = $value;    // Assign the value to session variable
			}
			
				return 1;    // return 1 (true)
		}else{
			return 3;    // return 3 (false)
		}
}
function login2(){
	
		extract($_POST);
		if(isset($email))
			$username = $email;
	$qry = $this->db->query("SELECT * FROM users where username = '".$username."' and password = '".md5($password)."' ");
	if($qry->num_rows > 0){    // check if query returns any result or not
		foreach ($qry->fetch_array() as $key => $value) {    // Iterate through the results
			if($key != 'passwors' && !is_numeric($key))    // Perform check on the key
				$_SESSION['login_'.$key] = $value;    // Assign the value to session variable
		}
		if($_SESSION['login_alumnus_id'] > 0){
			$bio = $this->db->query("SELECT * FROM alumnus_bio where id = ".$_SESSION['login_alumnus_id']);
			if($bio->num_rows > 0){    // check if query returns any result or not
				foreach ($bio->fetch_array() as $key => $value) {    // Iterate through the results
					if($key != 'passwors' && !is_numeric($key))    // Perform check on the key
						$_SESSION['bio'][$key] = $value;    // Assign the value to session variable
				}
			}
		}
		if($_SESSION['bio']['status'] != 1){    // check if status is 1 or not
				foreach ($_SESSION as $key => $value) {    // Iterate through the session
					unset($_SESSION[$key]);    // Unset the session variable
				}
				return 2 ;    // return 2 (false)
				exit;    // exit the function
			}
			return 1;    // return 1 (true)
	}else{
		return 3;    // return 3 (false)
	}
}
function logout(){    // Define function logout
	session_destroy();    // Destroy the session
	foreach ($_SESSION as $key => $value) {    // Iterate through the session
		unset($_SESSION[$key]);    // Unset the session variable
	}
	header("location:login.php");    // redirect to login page
}
function logout2(){    // Define function logout2
	session_destroy();    // Destroy the session
	foreach ($_SESSION as $key => $value) {    // Iterate through the session
		unset($_SESSION[$key]);    // Unset the session variable
	}
	header("location:../index.php");    // redirect to login page
}
function save_user(){    // Define function save_user
	extract($_POST);    // Extract all elements of $_POST array in respective variable
	$data = " name = '$name' ";    // Initialize data variable
	$data .= ", username = '$username' ";    // Concatenate data variable with username
	if(!empty($password))    // Check if password is empty or not
	$data .= ", password = '".md5($password)."' ";    // Concatenate data variable with md5 of password
	$data .= ", type = '$type' ";    // Concatenate data variable with type
	
	$chk = $this->db->query("Select * from users where username = '$username' and id !='$id' ")->num_rows;    // Check if username already exists
	if($chk > 0){    // If username already exists
		return 2;    // Return 2
		exit;    // Exit
	}
	if(empty($id)){    // Check if id is empty or not
		$save = $this->db->query("INSERT INTO users set ".$data);    // Insert data into users table
	}else{    // else body
		$save = $this->db->query("UPDATE users set ".$data." where id = ".$id);    // Update users table data
	}
	if($save){    // Check if data successfully saved
		return 1;    // Return 1
	}
}
function delete_user(){    // Define function delete_user
	extract($_POST);    // Extract all elements of $_POST array in respective variable
	$delete = $this->db->query("DELETE FROM users where id = ".$id);    // Delete data from users table
	if($delete)    // Check if data successfully deleted
		return 1;    // Return 1
}
function signup(){    // Define function signup
	extract($_POST);    // Extract all elements of $_POST array in respective variable
	$data = " name = '".$firstname.' '.$lastname."' ";    // Initialize data variable
	$data .= ", username = '$email' ";    // Concatenate data variable with username
	$data .= ", password = '".md5($password)."' ";    // Concatenate data variable with md5 of password
	$chk = $this->db->query("SELECT * FROM users where username = '$email' ")->num_rows;    // Check if username already exists
	if($chk > 0){    // If username already exists
		return 2;    // Return 2
		exit;    // Exit
	}
		$save = $this->db->query("INSERT INTO users set ".$data);    // Insert data into users table
	if($save){    // Check if data successfully saved
		$uid = $this->db->insert_id;    // Get the user id
		$data = '';    // Initialize data variable
		foreach($_POST as $k => $v){    // Iterate through $_POST array
			if($k =='password')    // Check if key is password or not
				continue;    // Continue
			if(empty($data) && !is_numeric($k) )    // Check if data is empty or not
				$data = " $k = '$v' ";    // Initialize data variable
			else
				$data .= ", $k = '$v' ";    // Concatenate data variable
		}
		if($_FILES['img']['tmp_name'] != ''){    // Check if file is uploaded or not
						$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];    // Initialize fname variable
						$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);    // Move uploaded file to a directory
						$data .= ", avatar = '$fname' ";    // Concatenate data variable with fname

		}
		$save_alumni = $this->db->query("INSERT INTO alumnus_bio set $data ");    // Insert data into alumnus_bio table
		if($data){    // Check if data successfully saved
			$aid = $this->db->insert_id;    // Get the alumnus id
			$this->db->query("UPDATE users set alumnus_id = $aid where id = $uid ");    // Update users table data
			$login = $this->login2();    // Call login2 function
			if($login)
			return 1;    // Return 1
		}
	}
}
function update_account(){    // update account function
	extract($_POST);    // extract POST global variable
	$data = " name = '".$firstname.' '.$lastname."' ";    // assign value to $data variable
	$data .= ", username = '$email' ";    // add value to $data variable
	if(!empty($password))    // check if password is empty or not
	$data .= ", password = '".md5($password)."' ";    // add value to $data variable
	$chk = $this->db->query("SELECT * FROM users where username = '$email' and id != '{$_SESSION['login_id']}' ")->num_rows;    // find total rows
	if($chk > 0){    // check if $chk is greater than 0 or not
		return 2;    // return 2
		exit;    // exit the function
	}
		$save = $this->db->query("UPDATE users set $data where id = '{$_SESSION['login_id']}' ");    // update table
	if($save){    // check if $save is true or not
		$data = '';    // initialize data variable
		foreach($_POST as $k => $v){    // iterate over $_POST
			if($k =='password')    // check if $k is equal to 'password'
				continue;    // continue to next iteration
			if(empty($data) && !is_numeric($k) )    // check if $data is empty or not and $k is not numeric or not
				$data = " $k = '$v' ";    // assign value to $data variable
			else
				$data .= ", $k = '$v' ";    // add value to $data variable
		}
		if($_FILES['img']['tmp_name'] != ''){    // check if $_FILES['img']['tmp_name'] is not empty
						$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];    // initialize $fname variable
						$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);    // move file to a location
						$data .= ", avatar = '$fname' ";    // add value to $data variable

		}
		$save_alumni = $this->db->query("UPDATE alumnus_bio set $data where id = '{$_SESSION['bio']['id']}' ");    // update data in table
		if($data){    // check if $data is true or not
			foreach ($_SESSION as $key => $value) {    // iterate over $_SESSION
				unset($_SESSION[$key]);    // unset the item of $_SESSION
			}
			$login = $this->login2();    // initialize $login variable
			if($login)    // check if $login is true or not
			return 1;    // return 1
		}
	}
}
function save_settings(){    // Defining function "save_settings"
	extract($_POST);    // extract all the post variables
	$data = " name = '".str_replace("'","&#x2019;",$name)."' ";    // Initialize the name variable
	$data .= ", email = '$email' ";    // Append email variable to the $data variable
	$data .= ", contact = '$contact' ";    // Append contact variable to the $data variable
	$data .= ", about_content = '".htmlentities(str_replace("'","&#x2019;",$about))."' ";    // Append about_content variable to the $data variable
	if($_FILES['img']['tmp_name'] != ''){    // Check if image is uploaded or not
					$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];    // Initialize the fname variable with the file name
					$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);    // Move the file to the "assets/uploads" folder
				$data .= ", cover_img = '$fname' ";    // Append cover_img variable to the $data variable

	}
	
	// echo "INSERT INTO system_settings set ".$data;    // Echo the query
	$chk = $this->db->query("SELECT * FROM system_settings");    // Check the existence of the record in system_settings table
	if($chk->num_rows > 0){    // If record exists
		$save = $this->db->query("UPDATE system_settings set ".$data);    // Update the record
	}else{    // else body
		$save = $this->db->query("INSERT INTO system_settings set ".$data);    // Insert the record
	}
	if($save){    // If record is inserted successfully
	$query = $this->db->query("SELECT * FROM system_settings limit 1")->fetch_array();    // Fetch the record from system_settings table
	foreach ($query as $key => $value) {    // Loop through the records
		if(!is_numeric($key))    // Check if $key is numeric or not
			$_SESSION['system'][$key] = $value;    // If not, then set the value of $key in $_SESSION["system"]
	}

		return 1;    // Return 1
			}
}


function save_donor(){    // Defining function "save_donor"
	extract($_POST);    // extract all the post variables
	$data = " name = '$name' ";    // Initialize name variable
	$data .= ", address = '$address' ";    // Append address variable to the $data variable
	$data .= ", email = '$email' ";    // Append email variable to the $data variable
	$data .= ", contact = '$contact' ";    // Append contact variable to the $data variable
	$data .= ", blood_group = '$blood_group' ";    // Append blood_group variable to the $data variable
		if(empty($id)){    // check if id is empty or not
			$save = $this->db->query("INSERT INTO donors set $data");    // Insert the record in donors table
		}else{    // else body
			$save = $this->db->query("UPDATE donors set $data where id = $id");    // Update the record in donors table
		}
	if($save)
		return 1;    // Return 1
}
function delete_donor(){    // Defining function "delete_donor"
	extract($_POST);    // extract all the post variables
	$delete = $this->db->query("DELETE FROM donors where id = ".$id);    // Delete the record from donors table
	if($delete){    // If record is deleted successfully
		return 1;    // Return 1
	}
}
function save_donation(){    // Defining function "save_donation"
	extract($_POST);    // extract all the post variables
	$data = " donor_id = '$donor_id' ";    // Initialize donor_id variable
	$data .= ", blood_group = '$blood_group' ";    // Append blood_group variable to the $data variable
	$data .= ", status = '$status' ";    // Append status variable to the $data variable
	$data .= ", volume = '$volume' ";    // Append volume variable to the $data variable
	$data .= ", date_created = '$date_created' ";    // Append date_created variable to the $data variable
		if(empty($id)){    // Check if id is empty or not
			$save = $this->db->query("INSERT INTO blood_inventory set $data");    // Insert the record in blood_inventory table
		}else{    // else body
			$save = $this->db->query("UPDATE blood_inventory set $data where id = $id");    // Update the record in blood_inventory table
		}
	if($save)
		return 1;    // Return 1
}
function delete_donation(){    // Defining function delete_donation
	extract($_POST);    // Extract the POST data
	$delete = $this->db->query("DELETE FROM blood_inventory where id = ".$id);    // Delete row from blood_inventory where id is $id
	if($delete){    // Check if delete is true
		return 1;    // Return 1
	}
}
function save_request(){    // Defining function save_request
	extract($_POST);    // Extract the POST data
	$data = " patient = '$patient' ";    // Initialize variable data with patient
	$data .= ", blood_group = '$blood_group' ";    // Update variable data with blood_group
	$data .= ", physician_name = '$physician_name' ";    // Update variable data with physician_name
	$data .= ", volume = '".($volume * 1000)."' ";    // Update variable data with volume
	if(isset($status))    // check if status is set or not
	$data .= ", status = '$status' ";    // Update variable data with status if isset
	
		if(empty($id)){    // check if id is empty or not
			$i = 1;    // Initialize variable i with value 1
			while($i == 1){    // while loop
				$rand = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';    // Initialize variable rand with given values
				$ref_code = substr(str_shuffle($rand), 0,8);    // Initialize variable ref_code with random value
				$chk = $this->db->query("SELECT * FROM requests where ref_code = '$ref_code'")->num_rows;    // Check if ref_code is available in database or not
				if($chk <= 0){    // Check ref_code is available or not
					$i = 0;    // Update variable i with 0
					$data .= ", ref_code = '$ref_code' ";    // Update variable data with ref_code
				}
			}
			$save = $this->db->query("INSERT INTO requests set $data");    // Insert the query with $data
		}else{
			$save = $this->db->query("UPDATE requests set $data where id = $id");    // Update the query with $data
		}
	if($save)    // Check if save is true
		return 1;    // Return 1
}
function delete_request(){    // Defining function delete_request
	extract($_POST);    // Extract the POST data
	$delete = $this->db->query("DELETE FROM requests where id = ".$id);    // Delete row from requests where id is $id
	if($delete){    // Check if delete is true
		return 1;    // Return 1
	}
}
function get_available(){    // Defining function get_available
	extract($_POST);    // Extract the POST data
	$where = '';    // Initialize variable where with blank value
	if(!empty($id)){    // Check if id is empty or not
		$where = " and request_id != $id ";    // Update variable where with value "request_id != $id"
	}
	$inn = $this->db->query("SELECT sum(volume) as total from blood_inventory where blood_group = '$blood_group' and status = 1 ");    // Retrieve the sum of volume where blood_group is $blood_group and status is 1
	$inn = $inn->num_rows > 0 ? $inn->fetch_array()['total'] : 0;    // Check if inn is available in database or not
	$out = $this->db->query("SELECT sum(volume) as total from blood_inventory where blood_group = '$blood_group' and status = 2 $where ");    // Retrieve the sum of volume where blood_group is $blood_group and status is 2
	$out = $out->num_rows > 0 ? $out->fetch_array()['total'] : 0;    // Check if out is available in database or not

	$available = $inn - $out;    // Perform subtraction
	$available = $available / 1000;    // Performing division
	return $available;    // return available
}
function chk_request(){    // Defining function chk_request
	extract($_POST);    // Extract the POST data
	$qry= $this->db->query("SELECT * FROM requests where ref_code = '$ref_code'");    // Retrieve data from requests where ref_code is $ref_code
	$data = array();    // Initialize variable data with array
	if($qry->num_rows > 0){    // check if qry is available in database or not
		$result = $qry->fetch_array();    // Initialize variable result with data from qry
		if($result['status'] == 0){    // check if status is 0
			$data['status'] = 2;    // Update variable data with status 2
		}else{
			$chk = $this->db->query("SELECT * FROM handedover_request hr inner join requests r on r.id = hr.request_id where r.ref_code = '$ref_code' ".($id > 0 ? " and hr.id != $id " : "")." ")->num_rows;    // Check if chk is available or not
			if($chk > 0){    // check if chk is available or not
			$data['status'] = 3;    // Update variable data with status 3
			}else{
				$data['status'] = 1;    // Update variable data with status 1
			foreach($result as $k => $v){    // Loop through result data
				if(!is_numeric($k)){    // Check if $k is numeric or not
					$data['data'][$k] = $v;    // Update variable data with $k => $v
				}
			}
			}
		}
	}else{    // Else body of if block
		$data['status'] = 0;    // assign 0 to status variable
}
if(isset($data['data']['volume']))
$data['data']['volumeL'] = $data['data']['volume'] / 1000;    // Divide volume by 1000 and assign to volumeL variable
return json_encode($data);
}
function save_handover(){
extract($_POST);    // Extract variable from $_POST
$data = "";    // Initialize variable data
foreach($_POST as $k => $v){    // Traverse the $_POST array
	if(!in_array($k, array('id','ref_code')) && !is_numeric($k)){    // Check if k is not in id and ref_code array and k is not numeric
		if(empty($data)){
			$data .= " $k='$v' ";
		}else{
			$data .= ", $k='$v' ";
		}
	}
}
if(empty($id)){
	$save = $this->db->query("INSERT INTO handedover_request set $data");    // Execute the query to insert data into handedover_request table
	$id=$this->db->insert_id;    // get the last inserted ID
}else{
	$save = $this->db->query("UPDATE handedover_request set $data where id = $id");    // Execute the query to update records
}

if($save){
	$request = $this->db->query("SELECT * FROM requests where ref_code = '$ref_code' ")->fetch_array();    // get the requests array using ref_code
	$data = " blood_group = '{$request['blood_group']}' ";
	$data .= ", volume = '{$request['volume']}' ";
	$data .= ", request_id = '{$request['id']}' ";
	$data .= ", status = '2' ";
	$chk = $this->db->query("SELECT * FROM blood_inventory where request_id= '{$request['id']}' ")->num_rows;    // check the number of rows in table blood_inventory
	if($chk> 0){
		$this->db->query("UPDATE blood_inventory set $data where request_id= '{$request['id']}' ");    // Update blood_inventory table
	}else{
		$this->db->query("INSERT INTO blood_inventory set $data");    // Insert data into blood_inventory table
	}
	return 1;
}
}
function delete_handover(){
extract($_POST);    // Extract variable from $_POST
$request_id = $this->db->query("SELECT * FROM handedover_request where id= '$id' ")->fetch_array()['request_id'];    // Get the request_id using id

$delete = $this->db->query("DELETE FROM handedover_request where id = ".$id);    // Execute the delete query
if($delete){
		$this->db->query("DELETE FROM blood_inventory where request_id= '$request_id' ");    // Execute the delete query
	return 1;
}
}
}

