<?php 

?>

<div class="container-fluid">
	
	<div class="row">
	<div class="col-lg-12">
			<button class="btn btn-primary float-right btn-sm" id="new_user"><i class="fa fa-plus"></i> New user</button>
	</div>
	</div>
	<br>
	<div class="row">
		<div class="card col-lg-12">
			<div class="card-body">
				<table class="table-striped table-bordered col-md-12">
			<thead>
				<tr>
					<th class="text-center">#</th>
					<th class="text-center">Name</th>
					<th class="text-center">Username</th>
					<th class="text-center">Type</th>
					<th class="text-center">Action</th>
				</tr>
			</thead>
			<tbody>
			<?php    // Start php code block
 					include 'db_connect.php';    // Include db connect file to perform database operations
 					$type = array("","Admin","Staff","Alumnus/Alumna");    // Define array of strings
 					$users = $conn->query("SELECT * FROM users order by name asc");    // Execute database query to get all user records
 					$i = 1;    // initialize the value of i to 1
 					while($row= $users->fetch_assoc()):    // Start while loop to fetch user records
				 ?>

				 <tr>
				 	<td class="text-center">
				 		<?php echo $i++ ?>
				 	</td>
				 	<td>
				 		<?php echo ucwords($row['name']) ?>
				 	</td>
				 	
				 	<td>
				 		<?php echo $row['username'] ?>
				 	</td>
				 	<td>
				 		<?php echo $type[$row['type']] ?>
				 	</td>
				 	<td>
				 		<center>
								<div class="btn-group">
								  <button type="button" class="btn btn-primary">Action</button>
								  <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								    <span class="sr-only">Toggle Dropdown</span>
								  </button>
								  <div class="dropdown-menu">
								    <a class="dropdown-item edit_user" href="javascript:void(0)" data-id = '<?php echo $row['id'] ?>'>Edit</a>
								    <div class="dropdown-divider"></div>
								    <a class="dropdown-item delete_user" href="javascript:void(0)" data-id = '<?php echo $row['id'] ?>'>Delete</a>
								  </div>
								</div>
								</center>
				 	</td>
				 </tr>
				<?php endwhile; ?>
			</tbody>
		</table>
			</div>
		</div>
	</div>

</div>

<script>    // Start Javascript code block
	$('table').dataTable();    // Add datatable for table
$('#new_user').click(function(){    // Add click listener for new_user button
	uni_modal('New User','manage_user.php')    // Create a pop-up with title "New User" and load manage_user.php page
})
$('.edit_user').click(function(){    // Add click listener for edit_user button
	uni_modal('Edit User','manage_user.php?id='+$(this).attr('data-id'))    // Create a pop-up with title "Edit User" and load manage_user.php page
})
$('.delete_user').click(function(){    // Add click listener for delete_user button
		_conf("Are you sure to delete this user?","delete_user",[$(this).attr('data-id')])    // Show a confirmation message on console
	})
	function delete_user($id){    // Define function delete_user
		start_load()    // Call function start_load()
		$.ajax({    // Ajax request
			url:'ajax.php?action=delete_user',    // Ajax request URL
			method:'POST',    // Ajax request method
			data:{id:$id},    // Data to be passed to the ajax request
			success:function(resp){    // If Ajax request is successful then run the following code
				if(resp==1){    // Check if the response is 1 or not
					alert_toast("Data successfully deleted",'success')    // Show a message on console
					setTimeout(function(){    // Wait for 1500 milliseconds
						location.reload()    // Reload the current page
					},1500)

				}
			}
		})
	}
</script>
