
<?php
ob_start();    // Turn on output buffering
$action = $_GET['action'];    // Get the action from URL and store in action variable
include 'admin_class.php';    // Include the admin_class file
$crud = new Action();    // Make a new object of class "Action"
if($action == 'login'){    // Check if action is login
	$login = $crud->login();    // Call login function
	if($login)    // if login function returns true
		echo $login;    // print login information
}
if($action == 'login2'){    // Check if action is login2
	$login = $crud->login2();    // Call login2 function
	if($login)    // if login2 function returns true
		echo $login;    // print login2 information
}
if($action == 'logout'){    // Check if action is logout
	$logout = $crud->logout();    // Call logout function
	if($logout)    // if logout function returns true
		echo $logout;    // print logout information
}
if($action == 'logout2'){    // Check if action is logout2
	$logout = $crud->logout2();    // Call logout2 function
	if($logout)    // if logout2 function returns true
		echo $logout;    // print logout2 information
}
if($action == 'save_user'){    // Check if action is save_user
	$save = $crud->save_user();    // Call save_user function
	if($save)    // if save_user function returns true
		echo $save;    // print save_user information
}
if($action == 'delete_user'){    // Check if action is delete_user
	$save = $crud->delete_user();    // Call delete_user function
	if($save)    // if delete_user function returns true
		echo $save;    // print delete_user information
}
if($action == 'signup'){    // Check if action is signup
	$save = $crud->signup();    // Call signup function
	if($save)    // if signup function returns true
		echo $save;    // print signup information
}
if($action == 'update_account'){    // Check if action is update_account
	$save = $crud->update_account();    // Call update_account function
	if($save)    // if update_account function returns true
		echo $save;    // print update_account information
}
if($action == "save_settings"){    // Check if action is save_settings
	$save = $crud->save_settings();    // Call save_settings function
	if($save)    // if save_settings function returns true
		echo $save;    // print save_settings information
}
if($action == "save_donor"){    // Check if action is save_donor
	$save = $crud->save_donor();    // Call save_donor function
	if($save)    // if save_donor function returns true
		echo $save;    // print save_donor information
}

if($action == "delete_donor"){    // Check if action is delete_donor
	$delete = $crud->delete_donor();    // Call delete_donor function
	if($delete)    // if delete_donor function returns true
		echo $delete;    // print delete_donor information
}

if($action == "save_donation"){    // Check if action is "save_donation"
    $save = $crud->save_donation();    // Save the donation
    if($save)
        echo $save;    // If save is successful then print the save status
}
if($action == "delete_donation"){    // Check if action is "delete_donation" 
    $save = $crud->delete_donation();    // Delete the donation
    if($save)
        echo $save;    // If save is successful then print the save status
}

if($action == "save_request"){    // Check if action is "save_request"
    $save = $crud->save_request();    // Save the request
    if($save)
        echo $save;    // If save is successful then print the save status
}
if($action == "delete_request"){    // Check if action is "delete_request"
    $save = $crud->delete_request();    // Delete the request
    if($save)
        echo $save;    // If save is successful then print the save status
}
if($action == "get_available"){    // Check if action is "get_available" 
    $get = $crud->get_available();    // Get the available blood group
    if($get)
        echo $get;    // If get is successful then print the get status
}

if($action == "chk_request"){    // Check if action is "chk_request"
    $get = $crud->chk_request();    // Get the request 
    if($get)
        echo $get;    // If get is successful then print the get status
}
if($action == "save_handover"){    // Check if action is "save_handover"
    $save = $crud->save_handover();    // Save the handover 
    if($save)
        echo $save;    // If save is successful then print the save status
}
if($action == "delete_handover"){    // Check if action is "delete_handover"
    $save = $crud->delete_handover();    // Delete the handover
    if($save)
        echo $save;    // If save is successful then print the save status
}

ob_end_flush();    // Flush and turn off output buffering
?>
